**To forget a device**

This example forgets device a device.

Command::

  aws cognito-idp forget-device --device-key us-west-2_abcd_1234-5678

