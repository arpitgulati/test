**To delete a group**

This example deletes a group.

Command::

  aws cognito-idp delete-group --user-pool-id us-west-2_aaaaaaaaa  --group-name MyGroupName
  
