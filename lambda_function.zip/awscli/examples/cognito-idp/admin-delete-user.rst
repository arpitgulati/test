**To delete a user**

This example deletes a user. 

Command::

  aws cognito-idp admin-delete-user --user-pool-id us-west-2_aaaaaaaaa --username diego@example.com 
  
