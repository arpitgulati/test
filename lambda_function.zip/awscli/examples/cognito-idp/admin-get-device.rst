**To get a device**

This example gets a device for username jane@example.com

Command::

  aws cognito-idp admin-get-device --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com --device-key us-west-2_abcd_1234-5678

