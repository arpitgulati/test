**To reset a user password**

This example resets the password for diego@example.com. 

Command::

  aws cognito-idp admin-reset-user-password --user-pool-id us-west-2_aaaaaaaaa --username diego@example.com 
