**To list devices for a user**

This example lists devices for username jane@example.com. 

Command::

  aws cognito-idp admin-list-devices --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com
