**To delete a user pool**

This example deletes a user pool using the user pool id, us-west-2_aaaaaaaaa.

Command::

  aws cognito-idp delete-user-pool --user-pool-id us-west-2_aaaaaaaaa

