**To set user settings**

This example sets the MFA delivery preference to EMAIL. 

Command::

  aws cognito-idp set-user-settings --access-token ACCESS_TOKEN --mfa-options DeliveryMedium=EMAIL

