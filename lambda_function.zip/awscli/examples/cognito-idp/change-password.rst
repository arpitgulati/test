**To change a password**

This example changes a password. 

Command::

  aws cognito-idp change-password --previous-password OldPassword --proposed-password NewPassword --access-token ACCESS_TOKEN
