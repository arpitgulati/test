**To update a user pool**

This example adds tags to a user pool.

Command::

  aws cognito-idp update-user-pool --user-pool-id us-west-2_aaaaaaaaa --user-pool-tags Team=Blue,Area=West
