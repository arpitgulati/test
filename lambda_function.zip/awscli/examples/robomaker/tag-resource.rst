**To tag a resource**

This example tags a resource. It attaches two tags: Region and Stage. 

Command::

   aws robomaker tag-resource --resource-arn "arn:aws:robomaker:us-west-2:111111111111:robot/MyRobot/1544035373264" --tags Region=North,Stage=Initial
