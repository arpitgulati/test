**To cancel a simulation job**

The following ``cancel-simulation-job`` example cancels the specified simulation job. ::

    aws robomaker cancel-simulation-job \
        --job arn:aws:robomaker:us-west-2:111111111111:simulation-job/sim-66bbb3gpxm8x
