**To delete a lifecycle policy**

The following example deletes the specified lifecycle policy.::

  aws dlm delete-lifecycle-policy --policy-id policy-0123456789abcdef0
