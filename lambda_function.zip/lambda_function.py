#!/usr/bin/python

import redis
import subprocess
#print dir(redis)
#from redis import StrictRedis
import os
import sys

#redis_host = "localhost"
#redis_port = 6379
#redis_password = "password"

def lambda_handler(event, context):
    try:
        #r = redis.StrictRedis(host=redis_host, port=redis_port, password=redis_password, decode_responses=True)
        #r.set("hello", "Hello Redis!!!")
        #msg = r.get("hello")
        #print(msg) 
        #print("hello")
#        arguments = sys.argv[1:]
#    var = arguments[0]
        print (event)
#        print event['key1']
        a = event['key1']
#        print type(a)
        print (a)
        b = str(a)
#    	print type(b)
        arguments = list(b.split(" "))
        str1 = " "
        var1 = str1.join(arguments)
        str2 = ""
        var = str2.join(arguments)
        print (var)
        lt1 = ["/tmp/"]
        varlist = list(var.split(" "))
#print type(varlist)
        print (varlist)
        lt2 = varlist
        localdir = ''.join([str(a) + b for a,b in zip(lt1,lt2)])
        print (localdir)
        os.chdir('/tmp/')
        os.makedirs(var)
 #       redis=redis.StrictRedis(host='localhost',port=6379,db=0,password='password')
        list2 = []
        redis1=redis.StrictRedis(host="rnd-redis.hlcpl1.ng.0001.aps1.cache.amazonaws.com", port=6379, db=10)
        print ("connected")
#a=redis.keys()
#b=redis.hmget company_name_and_path_map "HSK ENTERPRISES_1569309518414"
        var_temp=bytes(var1).encode()
        comp_path=redis1.hmget("company_name_and_path_map",var_temp)##"HSK ENTERPRISES_1569309518414")
        c=comp_path[0]
        path = c.split("E:")
        print (path)

        list3 = path[1]
        list2 = list3.split()   
        print (list2)
        list1 = ["s3://flo-tally-data"]
        print (list1)
        link = ''.join([str(a) + b for a,b in zip(list1,list2)])
        print (link)
#d = subprocess.check_output(['aws', 's3', 'ls', link , '--recursive'])
#print d
#os.chdir('/tmp/')
#os.chdir(var)
#localdir = "/tmp/osho"
        subprocess.check_output(['aws' , 's3' , 'cp' , link , localdir , '--recursive'])
        shutil.make_archive(var, 'zip', localdir)
        shutil.rmtree(localdir)
        subprocess.check_output(['aws','s3','sync','/tmp/random','s3://backup-download/backup-download/company-data'])
        z = ".zip"
        n = var + z
        print (n)
        url = ["https://content.flobiz.in/backup-download/company-data/"]
        uri = list(n.split(" "))
        print (type(uri))
        URL = ''.join([str(a) + b for a,b in zip(url,uri)])
        print (URL)

    except Exception as e:
        print(e)



