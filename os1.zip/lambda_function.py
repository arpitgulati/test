#!/usr/bin/python

import os
import sys
import subprocess
import redis

redis_host = "localhost"
redis_port = 6379
redis_password = "password"
print("ss")
def lambda_handler(event, context):
    try:
        print("osh")
        r = redis.StrictRedis(host=redis_host, port=redis_port, password=redis_password, decode_responses=True)
        r.set("hello", "Hello Redis!!!")
        msg = r.get("hello")
        print(msg) 
        print("hello")
    except Exception as e:
        print(e)



